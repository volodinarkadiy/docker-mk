<!--[metadata]>
+++
title = "push"
description = "Pushes service images."
keywords = ["fig, composition, compose, docker, orchestration, cli,  push"]
[menu.main]
identifier="push.compose"
parent = "smn_compose_cli"
+++
<![end-metadata]-->

# push

```
Usage: push [options] [SERVICE...]

Options:
    --ignore-push-failures  Push what it can and ignores images with push failures.
```

Pushes images for services.
