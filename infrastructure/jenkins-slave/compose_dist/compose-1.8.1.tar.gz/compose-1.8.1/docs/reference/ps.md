<!--[metadata]>
+++
title = "ps"
description = "Lists containers."
keywords = ["fig, composition, compose, docker, orchestration, cli,  ps"]
[menu.main]
identifier="ps.compose"
parent = "smn_compose_cli"
+++
<![end-metadata]-->

# ps

```
Usage: ps [options] [SERVICE...]

Options:
-q    Only display IDs
```

Lists containers.
